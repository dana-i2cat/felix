/*
 * Copyright 2003-2013 National Institute of Advanced Industrial Science and Technology
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package net.glambda.nsi2.topology;

import java.util.Calendar;
import java.util.Locale;
import java.util.TimeZone;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;

import net.glambda.nsi2.util.Serializer;
import nsidiscovery.nsa.*;
import nsidiscovery.protocol.*;
import nsitopology.BidirectionalPortType;
import nsitopology.LabelGroupType;
import nsitopology.PortGroupRelationType;
import nsitopology.PortGroupType;
import nsitopology.TopologyRelationType;
import nsitopology.TopologyType;

public class DDSCreator {

    private static final String NET_POSTFIX = ":topology";
    private static final String AIST_ID = "urn:ogf:network:aist.go.jp:2013";
    private static final String AIST_NETID = AIST_ID + NET_POSTFIX;
    private static final String AIST_UPA_NSAID = AIST_ID + ":nsa";
    private static final String AIST_AGGR_NSAID = AIST_ID + ":nsa:nsi-aggr";
    private static final String AIST_AGGR_URL =
            "https://163.220.30.174:28443/nsi2/services/ConnectionProvider";
    private static final String AIST_AGGR_REQ_URL =
            "https://163.220.30.174:28090/nsi2/services/ConnectionServiceRequester";

    private static final String AIST_UPA_URL =
            "https://163.220.30.173:22311/aist_upa/services/ConnectionProvider";
    private static final String AIST_TOPO_URL =
            "https://163.220.30.174:28443/NSI/aist.go.jp:2013:nml.xml";
    private static final String JGNX_ID = "urn:ogf:network:jgn-x.jp:2013";
    private static final String JGNX_NETID = JGNX_ID + NET_POSTFIX;
    private static final String VLAN_RANGE = "1779-1799";

    private static final nsidiscovery.nsa.ObjectFactory FACTORY_DISC_NSA =
            new nsidiscovery.nsa.ObjectFactory();
    private static final nsitopology.ObjectFactory FACTORY_TOPO = new nsitopology.ObjectFactory();

    private static final Calendar NOW_UTC;

    static {
        NOW_UTC = Calendar.getInstance(TimeZone.getTimeZone("GMT+0"));
        NOW_UTC.set(Calendar.MILLISECOND, 0);
    }

    private VcardsType createVcard(String url) {
        String firstname = "Atsuko";
        String familyname = "Takefusa";
        VcardsType.Vcard vcard = new VcardsType.Vcard();
        UidPropType uid = new UidPropType();
        vcard.setUid(uid);
        uid.setUri(url + "#adminContact");
        ProdidPropType pid = new ProdidPropType();
        vcard.setProdid(pid);
        pid.setText("aist");
        RevPropType rev = new RevPropType();
        vcard.setRev(rev);
        rev.setTimestamp(String.format(Locale.US, "%1$tY%1$tm%1$tdT%1$tH%1$tM%1$tSZ", NOW_UTC));
        KindPropType kp = new KindPropType();
        vcard.setKind(kp);
        kp.setText("individual");
        FnPropType fn = new FnPropType();
        fn.setText(firstname + " " + familyname);
        vcard.setFn(fn);
        NPropType n = new NPropType();
        vcard.setN(n);
        n.getGiven().add(firstname);
        n.getSurname().add(familyname);
        VcardsType admin = new VcardsType();
        admin.setVcard(vcard);
        return admin;
    }

    private NsaType baseNSA(String url) {
        NsaType nsa = new NsaType();
        nsa.setVersion(NOW_UTC);
        LocationType loc = new LocationType();
        nsa.setLocation(loc);
        loc.setLatitude(36.06F);
        loc.setLongitude(140.133F);
        nsa.setAdminContact(createVcard(url));
        return nsa;
    }

    private NsaType aistNSA() {
        NsaType nsa = baseNSA(AIST_UPA_URL);
        nsa.setId(AIST_UPA_NSAID);
        nsa.setName("aist.go.jp");
        nsa.getNetworkId().add(AIST_NETID);
        {
            InterfaceType intf = new InterfaceType();
            intf.setType(TopologyConstants.TYPE_TOPOLOGY);
            intf.setHref(AIST_TOPO_URL);
            nsa.getInterface().add(intf);
        }
        {
            InterfaceType intf = new InterfaceType();
            intf.setType(TopologyConstants.TYPE_PROVIDER);
            intf.setHref(AIST_UPA_URL);
            nsa.getInterface().add(intf);
        }
        FeatureType feat = new FeatureType();
        nsa.getFeature().add(feat);
        feat.setType(TopologyConstants.TYPE_DDS_uPA);
        nsa.getPeersWith().add(AIST_AGGR_NSAID);
        return nsa;
    }

    private NsaType aistAggr() {
        NsaType nsa = baseNSA(AIST_AGGR_URL);
        nsa.setId(AIST_AGGR_NSAID);
        nsa.setName("aist-nsi-aggr");
        {
            InterfaceType intf = new InterfaceType();
            intf.setType(TopologyConstants.TYPE_REQUESTER);
            intf.setHref(AIST_AGGR_REQ_URL);
            nsa.getInterface().add(intf);
        }
        {
            InterfaceType intf = new InterfaceType();
            intf.setType(TopologyConstants.TYPE_PROVIDER);
            intf.setHref(AIST_AGGR_URL);
            nsa.getInterface().add(intf);
        }
        FeatureType feat = new FeatureType();
        nsa.getFeature().add(feat);
        feat.setType(TopologyConstants.TYPE_DDS_AGGREGATOR);
        nsa.getPeersWith().add(AIST_UPA_NSAID);
        nsa.getPeersWith().add(JGNX_ID + ":nsa");
        return nsa;
    }

    private AnyType nsa2any(NsaType nsa) throws Exception {
        AnyType any = new AnyType();
        JAXBElement<NsaType> jaxb = FACTORY_DISC_NSA.createNsa(nsa);
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        DocumentBuilder db = dbf.newDocumentBuilder();
        Document doc = db.newDocument();
        JAXBContext context = JAXBContext.newInstance(nsa.getClass());
        context.createMarshaller().marshal(jaxb, doc);
        any.getAny().add(doc.getDocumentElement());
        return any;
    }

    private DocumentType createNSA() throws Exception {
        DocumentType doc = new DocumentType();
        doc.setNsa(AIST_UPA_NSAID);
        doc.setType(TopologyConstants.TYPE_DDS_NSA);
        doc.setContent(nsa2any(aistNSA()));
        doc.setVersion(NOW_UTC);
        Calendar ex = (Calendar) NOW_UTC;
        ex.add(Calendar.YEAR, 1);
        doc.setExpires(ex);
        return doc;
    }

    // /////////////////////////////////////////////////////////////////////////////////

    private JAXBElement<PortGroupType> createPortGroup(String id) {
        PortGroupType port = new PortGroupType();
        port.setId(id);
        return FACTORY_TOPO.createPortGroup(port);
    }

    private BidirectionalPortType createBiPort(String bi, String in, String out) {
        BidirectionalPortType biPort = new BidirectionalPortType();
        biPort.setId(bi);
        biPort.getRest().add(createPortGroup(in));
        biPort.getRest().add(createPortGroup(out));
        return biPort;
    }

    private PortGroupType createPortGroup(String id, String vlan) {
        PortGroupType port = new PortGroupType();
        port.setId(id);
        if (vlan != null) {
            LabelGroupType label = new LabelGroupType();
            label.setLabeltype(TopologyConstants.TYPE_VLAN);
            label.setValue(vlan);
            port.getLabelGroup().add(label);
        }
        return port;
    }

    private TopologyRelationType createRelation(boolean bIn, String name, String vlan) {
        TopologyRelationType rel = new TopologyRelationType();
        rel.setType(bIn ? TopologyConstants.TYPE_IN_BOUND_PORT
                : TopologyConstants.TYPE_OUT_BOUND_PORT);
        rel.getPortGroup().add(createPortGroup(name, vlan));
        return rel;
    }

    private void createBi(TopologyType topo, String bi, String in, String out) {
        topo.getGroup().add(createBiPort(bi, in, out));
        topo.getRelation().add(createRelation(true, in, VLAN_RANGE));
        topo.getRelation().add(createRelation(false, out, VLAN_RANGE));
    }

    private void createBiTerm(TopologyType topo, String name) {
        createBi(topo, AIST_NETID + ":bi-" + name, AIST_NETID + ":" + name + "-in", AIST_NETID
                + ":" + name + "-out");
    }

    private TopologyRelationType createRelation(boolean bIn, String name, String vlan, String pair) {
        TopologyRelationType rel = createRelation(bIn, name, vlan);
        PortGroupRelationType pairRel = new PortGroupRelationType();
        rel.getPortGroup().get(0).getRelation().add(pairRel);
        pairRel.setType(TopologyConstants.TYPE_IS_ALIAS);
        PortGroupType pairPort = new PortGroupType();
        pairPort.setId(pair);
        pairRel.getPortGroup().add(pairPort);

        return rel;
    }

    private void createBi(TopologyType topo, String src, String dst) {
        String bi = AIST_NETID + ":bi-" + src + "-" + dst;
        String inTail = ":" + dst + "-" + src;
        String in = AIST_NETID + inTail;
        String inPair = JGNX_NETID + inTail;
        String outTail = ":" + src + "-" + dst;
        String out = AIST_NETID + outTail;
        String outPair = JGNX_NETID + outTail;
        topo.getGroup().add(createBiPort(bi, in, out));
        topo.getRelation().add(createRelation(true, in, VLAN_RANGE, inPair));
        topo.getRelation().add(createRelation(false, out, VLAN_RANGE, outPair));
    }

    private TopologyType aistTopology() {
        TopologyType topo = new TopologyType();
        topo.setId(AIST_NETID);
        topo.setVersion(NOW_UTC);
        topo.setName("aist.go.jp");
        createBiTerm(topo, "ps");
        createBiTerm(topo, "video");
        createBiTerm(topo, "se1");
        createBiTerm(topo, "se2");
        createBi(topo, "aist", "jgn-x");
        return topo;
    }

    // /////////////////////////////////////////////////////////////////////////////////

    private void output(String[] args) throws Exception {
        String type = (args.length > 0 ? args[0] : "aggr.nsa");
        switch (type) {
        case "upa.nsa":
            NsaType nsa = aistNSA();
            System.out.println(Serializer.obj2xml(FACTORY_DISC_NSA.createNsa(nsa).getName(), nsa)
                    .trim());
            break;
        case "upa.topo":
            TopologyType topo = aistTopology();
            System.out.println(Serializer
                    .obj2xml(FACTORY_TOPO.createTopology(topo).getName(), topo).trim());
            break;
        case "aggr.nsa":
            NsaType aggr = aistAggr();
            System.out.println(Serializer.obj2xml(FACTORY_DISC_NSA.createNsa(aggr).getName(), aggr)
                    .trim());
            break;
        default:
            createNSA();
            break;
        }
    }

    public static void main(String[] args) throws Exception {
        DDSCreator app = new DDSCreator();
        app.output(args);
    }

}
