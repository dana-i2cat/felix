http://d.hatena.ne.jp/ozuma/20130511/1368284304

openssl genrsa 2048 > server.key
openssl req -new -key server.key -subj "/CN=127.0.0.2/OU=gridars-server/O=AIST/ST=TOKYO/C=JP" > csrserver2.pem
openssl ca -verbose -config openssl.cnf -batch -days 3650 -cert cacert.pem -keyfile caprivkey.pem -in csrserver2.pem -out server-cert2.pem

http://www.webtech.co.jp/blog/developer-news/1159/
http://www.webtech.co.jp/blog/developer-news/1780/

openssl req -config openssl.cnf -new -keyout yone.key.pem -out yone.req.pem -days 365 -extensions client_cert -nodes -subj "/CN=AIST nsi user/OU=gridars project/O=AIST/ST=TOKYO/C=JP"
ls -l yone.key.pem yone.req.pem 
openssl ca -config openssl.cnf -batch -cert cacert.pem -keyfile caprivkey.pem -policy policy_anything -out yone.cert.pem -extensions client_cert -infiles yone.req.pem
openssl pkcs12 -export -in yone.cert.pem -inkey yone.key.pem -certfile cacert.pem -out yone.p12 -password pass:password

openssl x509 -in yone.req.pem -out yone.cert.pem -req -signkey yone.key.pem -days 3650
openssl pkcs12 -export -inkey yone.key.pem -in yone.cert.pem -out yone.p12 -password pass:password -name "yone"

http://y-yagi.tumblr.com/post/18179788088

openssl genrsa -out client.key 2048 
openssl req -config openssl.cnf -new -key client.key -out client.csr -nodes -subj "/CN=AIST nsi user/OU=gridars project/O=AIST/ST=TOKYO/C=JP"
openssl x509 -in client.csr -out client-ca.crt -req -signkey client.key -days 3650 
openssl pkcs12 -export -inkey client.key -in client-ca.crt -out client.p12 -password pass:password -name "AIST nsi user" 
keytool -printcert -file client-ca.crt
rm -f s.jks
keytool -import -file client-ca.crt -alias client -keystore s.jks -storetype jks -storepass password -keypass password -noprompt
keytool -list -v -keystore s.jks -storepass password



http://techcommunity.softwareag.com/widget/pwiki/-/wiki/Main/How+do+I+generate+keystores+and+certificates+for+command+central;jsessionid=300A03376881D287B585029EA05B7C90

keytool -genkeypair -keystore cceroot.jks -alias cceroot -dname "cn=cceroot,o=sag" -keyalg RSA -ext bc:c -storepass manage -keypass manage -validity 7300
keytool -exportcert -keystore cceroot.jks -storepass manage -alias cceroot -file cceroot.cer

keytool -genkeypair -keystore spmnode.jks -alias spmnode -dname "cn=spmnode,o=sag" -keyalg RSA -storepass manage -keypass manage -validity 720  
keytool -certreq -keystore spmnode.jks -alias spmnode -dname "cn=spmnode,o=sag" -storepass manage -keypass manage -file spmnode.p10
keytool -gencert -alias cceroot -ext san=dns:spmnode.acme.com -keystore cceroot.jks -storepass manage -keypass manage -infile spmnode.p10 -outfile spmnode.cer -validity 720



http://se-bikou.blogspot.jp/2012/04/keytool.html

$ keytool -list -v -keystore demo.jks -storepass password -storetype JCEKS



