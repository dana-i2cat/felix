/*
 * Copyright 2003-2013 National Institute of Advanced Industrial Science and Technology
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package net.glambda.nsi2.impl;

import java.util.Calendar;
import java.util.List;

import net.glambda.nsi2.util.AbstractLog;

import org.apache.commons.logging.Log;
import org.ogf.schemas.nsi._2013._12.connection._interface.ServiceException;
import org.ogf.schemas.nsi._2013._12.connection.requester.ConnectionRequesterPort;
import org.ogf.schemas.nsi._2013._12.connection.types.ConnectionStatesType;
import org.ogf.schemas.nsi._2013._12.connection.types.DataPlaneStatusType;
import org.ogf.schemas.nsi._2013._12.connection.types.EventEnumType;
import org.ogf.schemas.nsi._2013._12.connection.types.GenericAcknowledgmentType;
import org.ogf.schemas.nsi._2013._12.connection.types.QueryNotificationConfirmedType;
import org.ogf.schemas.nsi._2013._12.connection.types.QueryRecursiveResultType;
import org.ogf.schemas.nsi._2013._12.connection.types.QueryResultResponseType;
import org.ogf.schemas.nsi._2013._12.connection.types.QuerySummaryResultType;
import org.ogf.schemas.nsi._2013._12.connection.types.ReservationConfirmCriteriaType;
import org.ogf.schemas.nsi._2013._12.framework.types.ServiceExceptionType;
import org.ogf.schemas.nsi._2013._12.framework.types.TypeValuePairListType;

public class EmptyRequesterPort implements ConnectionRequesterPort {

    protected static final Log logger = AbstractLog.getLog(EmptyRequesterPort.class);
    private static final EmptyRequesterPort instance = new EmptyRequesterPort();

    public static EmptyRequesterPort getInstance() {
        return instance;
    }

    @Override
    public void reserveConfirmed(String connectionId, String globalReservationId,
            String description, ReservationConfirmCriteriaType criteria) throws ServiceException {
        logger.info("EmptyRequesterPort: reserveConfirmed");
    }

    @Override
    public void reserveCommitConfirmed(String connectionId) throws ServiceException {
        logger.info("EmptyRequesterPort: reserveCommitConfirmed");
    }

    @Override
    public void reserveCommitFailed(String connectionId, ConnectionStatesType connectionStates,
            ServiceExceptionType serviceException) throws ServiceException {
        logger.info("EmptyRequesterPort: reserveCommitFailed");
    }

    @Override
    public void reserveAbortConfirmed(String connectionId) throws ServiceException {
        logger.info("EmptyRequesterPort: reserveAbortConfirmed");
    }

    @Override
    public void provisionConfirmed(String connectionId) throws ServiceException {
        logger.info("EmptyRequesterPort: provisionConfirmed");
    }

    @Override
    public void releaseConfirmed(String connectionId) throws ServiceException {
        logger.info("EmptyRequesterPort: releaseConfirmed");
    }

    @Override
    public void reserveFailed(String connectionId, ConnectionStatesType connectionStates,
            ServiceExceptionType serviceException) throws ServiceException {
        logger.info("EmptyRequesterPort: reserveFailed");
    }

    @Override
    public void terminateConfirmed(String connectionId) throws ServiceException {
        logger.info("EmptyRequesterPort: terminateConfirmed");
    }

    @Override
    public GenericAcknowledgmentType queryNotificationConfirmed(
            QueryNotificationConfirmedType queryNotificationConfirmed) throws ServiceException {
        logger.info("EmptyRequesterPort: queryNotificationConfirmed");
        return new GenericAcknowledgmentType();
    }

    @Override
    public void querySummaryConfirmed(List<QuerySummaryResultType> reservation)
            throws ServiceException {
        logger.info("EmptyRequesterPort: querySummaryConfirmed");
    }

    @Override
    public void queryResultConfirmed(List<QueryResultResponseType> result) throws ServiceException {
        logger.info("EmptyRequesterPort: queryResultConfirmed");
    }

    @Override
    public void queryRecursiveConfirmed(List<QueryRecursiveResultType> reservation)
            throws ServiceException {
        logger.info("EmptyRequesterPort: queryRecursiveConfirmed");
    }

    @Override
    public void error(ServiceExceptionType serviceException) throws ServiceException {
        logger.info("EmptyRequesterPort: error");
    }

    @Override
    public void errorEvent(String connectionId, long notificationId, Calendar timeStamp,
            EventEnumType event, String originatingConnectionId, String originatingNSA,
            TypeValuePairListType additionalInfo, ServiceExceptionType serviceException)
            throws ServiceException {
        logger.info("EmptyRequesterPort: errorEvent");
    }

    @Override
    public void messageDeliveryTimeout(String connectionId, long notificationId,
            Calendar timeStamp, String correlationId) throws ServiceException {
        logger.info("EmptyRequesterPort: messageDeliveryTimeout");
    }

    @Override
    public void dataPlaneStateChange(String connectionId, long notificationId, Calendar timeStamp,
            DataPlaneStatusType dataPlaneStatus) throws ServiceException {
        logger.info("EmptyRequesterPort: dataPlaneStateChange");
    }

    @Override
    public void reserveTimeout(String connectionId, long notificationId, Calendar timeStamp,
            int timeoutValue, String originatingConnectionId, String originatingNSA)
            throws ServiceException {
        logger.info("EmptyRequesterPort: reserveTimeout");
    }

}
