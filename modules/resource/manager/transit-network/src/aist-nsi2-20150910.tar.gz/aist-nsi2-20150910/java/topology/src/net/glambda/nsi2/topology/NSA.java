/*
 * Copyright 2003-2013 National Institute of Advanced Industrial Science and Technology
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package net.glambda.nsi2.topology;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import net.glambda.nsi2.topology.STP.STPType;
import net.glambda.nsi2.util.AbstractLog;

import org.apache.commons.logging.Log;

public class NSA {

    protected static final Log logger = AbstractLog.getLog(NSA.class);

    private final String ets, name, shortName;
    private final String csEndpoint;
    private final LinkedList<STP> inStps;
    private final LinkedList<STP> outStps;
    private final LinkedList<STP> biStps;
    private final LinkedList<STP> stps;
    private final String topoUrl;
    private final boolean vlanTransSupported;

    private final static String[] VLAN_TRANS_SUPPORTED = { ".*es\\.net.*", ".*icair\\.org.*",
            ".*netherlight\\.net.*" };

    public NSA(String name, String csEndpoint) {
        this(name, name, csEndpoint, null, null, null, "");
    }

    public NSA(String ets, String name, String csEndpoint, LinkedList<STP> inStps,
            LinkedList<STP> outStps, LinkedList<STP> biStps) {
        this(ets, name, csEndpoint, inStps, outStps, biStps, "");
    }

    public NSA(String ets, String name, String csEndpoint, LinkedList<STP> inStps,
            LinkedList<STP> outStps, LinkedList<STP> biStps, String topoUrl) {
        this.ets = ets.trim();
        this.name = name.trim();
        this.shortName = shortName(name);
        this.csEndpoint = csEndpoint.trim();
        this.inStps = inStps;
        this.outStps = outStps;
        this.biStps = biStps;
        this.stps = new LinkedList<STP>();
        if (inStps != null) {
            this.stps.addAll(inStps);
        }
        if (outStps != null) {
            this.stps.addAll(outStps);
        }
        if (biStps != null) {
            this.stps.addAll(biStps);
        }
        for (STP stp : stps) {
            stp.setNSA(this);
        }
        nsaMap.put(this.name, this);
        if (!this.name.equals(this.ets)) {
            nsaMap.put(this.ets, this);
        }
        nsaMap.put(this.shortName, this);
        this.topoUrl = topoUrl;
        this.vlanTransSupported = isVlanTrans(ets);
    }

    private boolean isVlanTrans(String ets) {
        for (String key : VLAN_TRANS_SUPPORTED) {
            if (ets.matches(key)) {
                return true;
            }
        }
        return false;
    }

    private static final Pattern NAME = Pattern.compile("urn:ogf:network:([^:]+):");

    private static String shortName(String name) {
        Matcher m = NAME.matcher(name);
        if (m.find()) {
            return m.group(1);
        } else {
            return name;
        }
    }

    private static final HashMap<String, NSA> nsaMap = new HashMap<String, NSA>();

    public static NSA findNSA(String name) {
        NSA nsa = nsaMap.get(name);
        if (nsa != null) {
            return nsa;
        } else {
            return nsaMap.get(shortName(name));
        }
    }

    public String ets() {
        return ets;
    }

    public String name() {
        return name;
    }

    public String shortName() {
        return shortName;
    }

    public String csEndpoint() {
        return csEndpoint;
    }

    public LinkedList<STP> inStps() {
        return inStps;
    }

    public LinkedList<STP> outStps() {
        return outStps;
    }

    public LinkedList<STP> biStps() {
        return biStps;
    }

    public LinkedList<STP> stps() {
        return stps;
    }

    public String topoUrl() {
        return topoUrl;
    }

    public boolean isVlanTransSupported() {
        return vlanTransSupported;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(name);
        sb.append("\n    ETS\t");
        sb.append(ets);
        sb.append("\n    URL\t");
        sb.append(csEndpoint);
        sb.append("\n    short\t");
        sb.append(shortName);
        sb.append("\n    vlanTrans\t");
        sb.append(vlanTransSupported);
        sb.append("\n    ");
        for (STP stp : stps) {
            sb.append("STP(");
            sb.append(stp.type());
            sb.append(") ");
            sb.append(stp.stpid());
            if (stp.isConnected()) {
                STP c = stp.connectedTo();
                if (c != null) {
                    sb.append("\n        connTo ");
                    sb.append(c.stpid());
                } else {
                    sb.append("\nERR     connTo ");
                    sb.append(stp.connectedToSTPName());
                }
            } else if (stp.type() == STPType.BI) {
                STPGroup group = (STPGroup) stp;
                for (STP port : group.ports()) {
                    sb.append("\n        port   ");
                    sb.append(port.stpid());
                }
            }
            if (stp.vlans() != null) {
                sb.append("\n        vlan   ");
            } else {
                sb.append("\nERR     vlan   ");
            }
            sb.append(stp.vlans());
            sb.append("\n    ");
        }
        return sb.toString().trim();
    }
}
