/*
 * Copyright 2003-2013 National Institute of Advanced Industrial Science and Technology
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package net.glambda.pathfinder;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

public class PathFindingResult implements Serializable {

    private static final long serialVersionUID = -7131833838361141947L;

    public final String queryId; // MUST
    public final List<Path> ero; // if success: MUST, else (no route): null
    public final List<Path> primary; // if protection==true && success: MUST,
                                     // else:
    // null
    public final List<Path> secondary; // if protection==true && success: MUST,
                                       // else:
    // null
    public final Map<String, List<Float>> constraintResults; // OPT

    public PathFindingResult(String queryId, List<Path> ero) {
        this(queryId, ero, null, null);
    }

    public PathFindingResult(String queryId, List<Path> ero, List<Path> primary,
            List<Path> secondary) {
        this.queryId = queryId;
        this.ero = ero;
        this.primary = primary;
        this.secondary = secondary;
        this.constraintResults = null;
    }

    public String toString() {
        StringBuffer sb = new StringBuffer();
        String crlf = System.getProperty("line.separator");
        sb.append(this.getClass().getName());
        sb.append(":");
        sb.append(queryId);
        sb.append(crlf);
        if (ero != null) {
            sb.append(toPathString("ero", ero));
            sb.append(crlf);
        }
        if (primary != null) {
            sb.append(toPathString("primary", primary));
            sb.append(crlf);
        }
        if (secondary != null) {
            sb.append(toPathString("secondary", secondary));
        }
        return sb.toString();
    }

    private String toPathString(String name, List<Path> list) {
        StringBuffer sb = new StringBuffer();
        sb.append(name);
        sb.append(": [");
        for (Path p : list) {
            sb.append(p.toString());
            sb.append(",");
        }
        sb.append("]");
        return sb.toString();
    }

}
