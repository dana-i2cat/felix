#!/bin/sh -x

rm -f *cert *jks *certreq

make ca
make ADDRESS=163.220.30.173 certs
make ADDRESS=163.220.30.174 certs

# for local test
make ADDRESS=127.0.0.1 certs
ln -s nsi-127.0.0.1.jks client.jks
ln -s nsi-127.0.0.1.jks server.jks

VER=`date +%Y%m%d%H%M%S`
tar zcf aist-certs-${VER}.tar.gz *cert *jks Makefile make-aist-certs.sh
