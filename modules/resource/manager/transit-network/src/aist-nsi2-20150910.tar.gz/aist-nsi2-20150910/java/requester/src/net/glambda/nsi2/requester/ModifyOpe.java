/*
 * Copyright 2003-2013 National Institute of Advanced Industrial Science and Technology
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package net.glambda.nsi2.requester;

import javax.xml.ws.Holder;

import net.glambda.nsi2.impl.ProviderPortWithHeader;
import net.glambda.nsi2.util.NSITextDump;
import net.glambda.nsi2.util.TypesBuilder;

import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.OptionBuilder;
import org.apache.commons.cli.Options;
import org.ogf.schemas.nsi._2013._12.connection.provider.ConnectionProviderPort;
import org.ogf.schemas.nsi._2013._12.connection.types.ReservationRequestCriteriaType;
import org.ogf.schemas.nsi._2013._12.connection.types.ScheduleType;
import org.ogf.schemas.nsi._2013._12.framework.headers.CommonHeaderType;

public class ModifyOpe extends OpeBase {

    public final static String OPT_VERSION = "v";

    @Override
    protected void addOptions(Options options) {
        addConnIDOption(options);

        addScheduleOption(options);
        addBandwidthOption(options, false);
        addServiceTypeOption(options);

        OptionBuilder.hasArgs(1);
        OptionBuilder.isRequired(true);
        OptionBuilder.withArgName("version");
        OptionBuilder.withDescription("new version of the reservation");
        options.addOption(OptionBuilder.create(OPT_VERSION));
    }

    @Override
    void operation(ConnectionProviderPort provider, CommandLine cmd) throws Exception {
        String globalReservationId = null;
        String description = null;
        ScheduleType schedule = makeSched(cmd);
        long capacity;
        if (cmd.hasOption(OPT_BANDWIDTH)) {
            capacity = Long.parseLong(cmd.getOptionValue(OPT_BANDWIDTH));
        } else {
            capacity = 0;
        }
        if (schedule == null && capacity == 0) {
            throw new Exception("no modification parameters specified. type 'help modify'");
        }
        ReservationRequestCriteriaType criteria =
                TypesBuilder.makeReservationRequestCriteriaType(schedule, capacity);
        if (cmd.hasOption(OPT_SERVICETYPE)) {
            criteria.setServiceType(cmd.getOptionValue(OPT_SERVICETYPE));
        }
        criteria.setVersion(Integer.parseInt(cmd.getOptionValue(OPT_VERSION)));
        CommonHeaderType header = getCommonHeader();
        ProviderPortWithHeader port = new ProviderPortWithHeader(header, provider);

        Holder<String> holder = new Holder<String>();
        String connectionId = holder.value = getConnectionID(cmd);

        log(cmd, "**** reservation(modify) request ****");
        log(cmd, NSITextDump.toString(header, globalReservationId, description, connectionId,
                criteria));
        port.reserve(holder, globalReservationId, description, criteria);
    }

}
