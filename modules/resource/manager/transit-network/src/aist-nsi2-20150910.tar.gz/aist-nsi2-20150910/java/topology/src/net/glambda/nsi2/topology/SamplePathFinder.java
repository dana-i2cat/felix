/*
 * Copyright 2003-2013 National Institute of Advanced Industrial Science and Technology
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package net.glambda.nsi2.topology;

import java.util.HashMap;
import java.util.LinkedList;

import org.ogf.schemas.nsi._2013._12.connection._interface.ServiceException;

import net.glambda.nsi2.util.ErrorID;
import net.glambda.nsi2.util.NSIConstants;
import net.glambda.nsi2.util.NSIExceptionUtil;
import net.glambda.nsi2.util.TypesBuilder;

public class SamplePathFinder {

    /*
     * See Chapter 6.3 of http://www.amazon.co.jp/dp/4873114284
     */

    private enum Color {
        White, Gray, Black
    };

    private class Entry {
        final STP stp;
        Entry pred;
        Color color;
        int vlan = NSIConstants.VLANID_NOTUSE;
        final LinkedList<Entry> neighbours = new LinkedList<Entry>();

        Entry(STP stp) {
            this.stp = stp;
            clear();
        }

        void clear() {
            this.pred = null;
            // this.dist = Integer.MAX_VALUE;
            this.color = Color.White;
            this.vlan = NSIConstants.VLANID_NOTUSE;
        }

        private void addNeighBour(STP stp) throws ServiceException {
            Entry e = getEntry(stp);
            neighbours.add(e);
        }

        void setNeighbours() throws ServiceException {
            STP conn = this.stp.connectedTo();
            if (conn != null) {
                addNeighBour(conn);
            }
            for (STP s : stp.nsa().stps()) {
                if (s != stp) {
                    addNeighBour(s);
                }
            }
        }

        boolean hasVlan(int vlan) {
            return stp.vlans().hasVlan(vlan);
        }

        public String toString() {
            return TypesBuilder.makeStpWithVlan(stp.stpid(), vlan);
        }
    }

    private final HashMap<String, Entry> entryMap;

    public SamplePathFinder() throws ServiceException {
        this(new LinkedList<NSA>());
    }

    public SamplePathFinder(LinkedList<NSA> nsaList) throws ServiceException {
        this.entryMap = new HashMap<String, Entry>();
        for (NSA nsa : nsaList) {
            for (STP stp : nsa.stps()) {
                this.entryMap.put(stp.stpid(), new Entry(stp));
                if (!stp.stpid().equals(stp.stpid())) {
                    this.entryMap.put(stp.stpid(), new Entry(stp));
                }
            }
        }
        for (Entry e : this.entryMap.values()) {
            e.setNeighbours();
        }
    }

    private void clear() {
        for (Entry e : this.entryMap.values()) {
            e.clear();
        }
    }

    private Entry getEntry(String name, int vlan) throws ServiceException {
        Entry e = getEntry(name);
        if (e != null) {
            e.vlan = vlan;
        }
        return e;
    }

    private Entry getEntry(String name) throws ServiceException {
        Entry e = entryMap.get(name);
        if (e != null) {
            return e;
        } else {
            throw NSIExceptionUtil.makeServiceException(ErrorID.UNKNOWN_STP, null, name);
        }
    }

    private Entry getEntry(STP stp) throws ServiceException {
        return getEntry(stp.stpid());
    }

    public LinkedList<Term> search(String srcname, int srcvlan, String dstname, int dstvlan)
            throws ServiceException {
        if (srcvlan <= 0) {
            throw NSIExceptionUtil.makeServiceException(ErrorID.MISSING_PARAMETER, null,
                    "missing vlan : " + srcname);
        }
        if (dstvlan <= 0) {
            throw NSIExceptionUtil.makeServiceException(ErrorID.MISSING_PARAMETER, null,
                    "missing vlan : " + dstname);
        }
        clear();
        Entry src = getEntry(srcname, srcvlan);
        Entry dst = getEntry(dstname, dstvlan);
        if (!src.hasVlan(srcvlan)) {
            throw NSIExceptionUtil.makeServiceException(ErrorID.MISSING_PARAMETER, null, srcname
                    + " not support vlan=" + srcvlan);
        }
        if (!dst.hasVlan(dstvlan)) {
            throw NSIExceptionUtil.makeServiceException(ErrorID.MISSING_PARAMETER, null, dstname
                    + " not support vlan=" + dstvlan);
        }
        //
        src.color = Color.Gray;
        // start.dist = 0;
        LinkedList<Entry> queue = new LinkedList<Entry>();
        queue.add(src);
        //
        int vlan = srcvlan;
        int vlan2 = (srcvlan != dstvlan ? dstvlan : -1);
        while (!queue.isEmpty()) {
            Entry u = queue.getFirst();
            if (!u.hasVlan(vlan)) {
                queue.removeFirst();
                continue;
            }
            for (Entry v : u.neighbours) {
                if (v.color != Color.White) {
                    continue;
                }
                if (vlan2 < 0) {
                    if (!v.hasVlan(vlan)) {
                        continue;
                    }
                } else {
                    if (u.stp.nsa() == v.stp.nsa() && u.stp.nsa().isVlanTransSupported()
                            && v.hasVlan(vlan2)) {
                        vlan = vlan2;
                        vlan2 = -1;
                    } else if (!v.hasVlan(vlan)) {
                        continue;
                    }
                }
                v.vlan = vlan;
                v.pred = u;
                v.color = Color.Gray;
                queue.add(v);
            }
            queue.removeFirst();
            u.color = Color.Black;
        }
        //
        LinkedList<Term> path = new LinkedList<Term>();
        path.add(new Term(dst.stp, dstvlan));
        Entry e = dst.pred;
        while (e != null) {
            path.addFirst(new Term(e.stp, e.vlan));
            e = e.pred;
        }
        if (path.size() <= 1) {
            path.clear(); // means cannot connect
        }
        //
        LinkedList<Term> biPath = new LinkedList<Term>();
        STPGroup prevGroup = null;
        for (Term term : path) {
            STP stp = term.stp();
            STPGroup group = STPGroup.findSTPGroup(stp.stpid());
            if (group != null) {
                if (group != prevGroup) {
                    biPath.add(term);
                    prevGroup = group;
                } else {
                    throw NSIExceptionUtil.makeServiceException(ErrorID.NO_PATH_FOUND, null);
                }
            } else {
                throw NSIExceptionUtil.makeServiceException(ErrorID.MISSING_PARAMETER, null,
                        "cannot find BidirectionalPort of " + stp.stpid());
            }
        }
        if (biPath.isEmpty()) {
            throw NSIExceptionUtil.makeServiceException(ErrorID.NO_PATH_FOUND, null);
        }
        return biPath;
    }

    private static void test(SamplePathFinder finder, STP src, int srcvlan, STP dst, int dstvlan) {
        String start = src.stpid();
        String end = dst.stpid();
        System.out.println("SRC  " + TypesBuilder.makeStpWithVlan(start, srcvlan));
        System.out.println("DST  " + TypesBuilder.makeStpWithVlan(end, dstvlan));
        LinkedList<Term> path;
        long s = System.currentTimeMillis();
        try {
            path = finder.search(start, srcvlan, end, dstvlan);
        } catch (Exception e) {
            System.out.println("\tno route");
            System.out.println();
            return;
        }
        long e = System.currentTimeMillis();
        StringBuffer sb = new StringBuffer();
        if (path.size() % 2 != 0) {
            sb.append("*");
        }
        for (Term term : path) {
            sb.append("\t");
            sb.append(term.stpid());
            sb.append("\n");
        }
        System.out.print(sb.toString());
        System.out.println(e - s + " msec");
        System.out.println();
    }

    public static void test(SamplePathFinder finder, NSA netA, int srcvlan, NSA netZ, int dstvlan)
            throws ServiceException {
        for (STP stpA : netA.biStps()) {
            for (STP stpZ : netZ.biStps()) {
                if (stpA == stpZ) {
                    continue;
                }
                test(finder, stpA, srcvlan, stpZ, dstvlan);
            }
        }
    }

    private static void test(int vlan) throws ServiceException {
        LinkedList<NSA> netList = TopologyLoader.loadAll();
        for (NSA nsa : netList) {
            System.out.println(nsa);
            System.out.println();
        }
        System.out.println();
        System.out.println();
        //
        SamplePathFinder finder = new SamplePathFinder(netList);
        int nNet = netList.size();
        for (int i = 0; i < nNet; i++) {
            NSA netA = netList.get(i);
            for (int j = 0; j < nNet; j++) {
                NSA netZ = netList.get(j);
                test(finder, netA, vlan, netZ, vlan);
            }
        }
    }

    private static void test2() throws ServiceException {
        LinkedList<NSA> netList = TopologyLoader.loadAll();
        SamplePathFinder finder = new SamplePathFinder(netList);

        test(finder, STP.findSTP("urn:ogf:network:aist.go.jp:2013:topology:bi-ps"), 1780,
                STP.findSTP("urn:ogf:network:aist.go.jp:2013:topology:bi-aist-jgn-x"), 1780);
        test(finder, STP.findSTP("urn:ogf:network:aist.go.jp:2013:topology:bi-ps"), 1780,
                STP.findSTP("urn:ogf:network:jgn-x.jp:2013:topology:bi-ps"), 1780);
        test(finder, STP.findSTP("urn:ogf:network:aist.go.jp:2013:topology:bi-ps"), 1780,
                STP.findSTP("urn:ogf:network:icair.org:2013:topology:esnet"), 1781);
        test(finder, STP.findSTP("urn:ogf:network:aist.go.jp:2013:topology:bi-ps"), 1780,
                STP.findSTP("urn:ogf:network:es.net:2013::fnal-mr2:ae0:+"), 1781);
        test(finder, STP.findSTP("urn:ogf:network:aist.go.jp:2013:topology:bi-ps"), 1780,
                STP.findSTP("urn:ogf:network:es.net:2013::fnal-mr2:ae0:+"), 4000);
    }

    public static void main(String[] args) throws Exception {
        int vlan = (args.length > 0 ? Integer.parseInt(args[0]) : NSIConstants.VLANID_MIN);
        test(vlan);
        test2();
    }
}
