/*
 * Copyright 2003-2013 National Institute of Advanced Industrial Science and Technology
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package net.glambda.nsi2.topology;

import net.glambda.nsi2.util.NSIConstants;
import net.glambda.nsi2.util.TypesBuilder;

public class Term {

    private final STP stp;
    private final String fullStpid;
    private final int vlan;

    public Term(STP stp) {
        this.stp = stp;
        this.fullStpid = stp.stpid();
        this.vlan = NSIConstants.VLANID_NOTUSE;
    }

    public Term(STP stp, int vlan) {
        this.stp = stp;
        this.fullStpid = TypesBuilder.makeStpWithVlan(stp.stpid(), vlan);
        this.vlan = vlan;
    }

    public STP stp() {
        return stp;
    }

    public String stpid() {
        return fullStpid;
    }

    public int vlan() {
        return vlan;
    }

    public String toString() {
        return fullStpid;
    }

}
