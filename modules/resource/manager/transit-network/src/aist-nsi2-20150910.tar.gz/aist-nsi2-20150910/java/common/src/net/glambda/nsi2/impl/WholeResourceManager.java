/*
 * Copyright 2003-2013 National Institute of Advanced Industrial Science and Technology
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package net.glambda.nsi2.impl;

import org.apache.commons.logging.Log;

import net.glambda.nsi2.converter.ToRMS;
import net.glambda.nsi2.util.AbstractLog;
import net.glambda.nsi2.util.ErrorID;
import net.glambda.nsi2.util.NSIExceptionUtil;
import net.glambda.rms.EthernetResourceManager;
import net.glambda.rms.LambdaResourceManager;
import net.glambda.rms.NSI2ResourceManagerBase;
import net.glambda.rms.Notifier;
import net.glambda.rms.ODUResourceManager;
import net.glambda.rms.TransferResourceManager;
import net.glambda.rms.types.CommonHeaderType;
import net.glambda.rms.types.CriteriaBase;
import net.glambda.rms.types.EthernetCriteria;
import net.glambda.rms.types.LambdaCriteria;
import net.glambda.rms.types.ODUCriteria;
import net.glambda.rms.types.ServiceException;
import net.glambda.rms.types.TransferCriteria;

public class WholeResourceManager implements NSI2ResourceManagerBase, EthernetResourceManager,
        ODUResourceManager, LambdaResourceManager, TransferResourceManager {

    protected static final Log logger = AbstractLog.getLog(WholeResourceManager.class);

    private final NSI2ResourceManagerBase base;
    private final EthernetResourceManager ether;
    private final ODUResourceManager odu;
    private final LambdaResourceManager lambda;
    private final TransferResourceManager transfer;

    public WholeResourceManager(NSI2ResourceManagerBase rm) {
        this.base = rm;
        if (rm instanceof EthernetResourceManager) {
            this.ether = (EthernetResourceManager) rm;
            logger.info("EthernetResourceManager ON");
        } else {
            this.ether = null;
            logger.info("EthernetResourceManager OFF");
        }
        if (rm instanceof ODUResourceManager) {
            this.odu = (ODUResourceManager) rm;
            logger.info("ODUResourceManager ON");
        } else {
            this.odu = null;
            logger.info("ODUResourceManager OFF");
        }
        if (rm instanceof LambdaResourceManager) {
            this.lambda = (LambdaResourceManager) rm;
            logger.info("LambdaResourceManager ON");
        } else {
            this.lambda = null;
            logger.info("LambdaResourceManager OFF");
        }
        if (rm instanceof TransferResourceManager) {
            this.transfer = (TransferResourceManager) rm;
            logger.info("TransferResourceManager ON");
        } else {
            this.transfer = null;
            logger.info("TransferResourceManager OFF");
        }
    }

    private void check(Object o, String connectionId, String name) throws ServiceException {
        if (o == null) {
            throw ToRMS.convert(NSIExceptionUtil.makeServiceException(ErrorID.MISSING_PARAMETER,
                    connectionId, name));
        }
    }

    public void reserve(CommonHeaderType header, String connectionId, String globalReservationId,
            String description, CriteriaBase criteria) throws ServiceException {
        if (criteria instanceof EthernetCriteria) {
            logger.info("call reserve(EthernetCriteria)");
            reserve(header, connectionId, globalReservationId, description,
                    (EthernetCriteria) criteria);
        } else if (criteria instanceof ODUCriteria) {
            logger.info("call reserve(ODUCriteria)");
            reserve(header, connectionId, globalReservationId, description, (ODUCriteria) criteria);
        } else if (criteria instanceof LambdaCriteria) {
            logger.info("call reserve(LambdaCriteria)");
            reserve(header, connectionId, globalReservationId, description,
                    (LambdaCriteria) criteria);
        } else if (criteria instanceof TransferCriteria) {
            logger.info("call reserve(TransferCriteria)");
            reserve(header, connectionId, globalReservationId, description,
                    (TransferCriteria) criteria);
        } else if (criteria != null) {
            throw ToRMS.convert(NSIExceptionUtil.makeServiceException(
                    ErrorID.UNSUPPORTED_PARAMETER, connectionId, "unsupported criteria: "
                            + criteria.getClass().getCanonicalName()));
        } else {
            throw ToRMS.convert(NSIExceptionUtil.makeServiceException(ErrorID.MISSING_PARAMETER,
                    connectionId, "criteria is null"));
        }
    }

    public void modify(CommonHeaderType header, String connectionId, String globalReservationId,
            String description, CriteriaBase criteria) throws ServiceException {
        if (criteria instanceof EthernetCriteria) {
            logger.info("call modify(EthernetCriteria)");
            modify(header, connectionId, globalReservationId, description,
                    (EthernetCriteria) criteria);
        } else if (criteria instanceof ODUCriteria) {
            logger.info("call modify(ODUCriteria)");
            modify(header, connectionId, globalReservationId, description, (ODUCriteria) criteria);
        } else if (criteria instanceof LambdaCriteria) {
            logger.info("call modify(LambdaCriteria)");
            modify(header, connectionId, globalReservationId, description,
                    (LambdaCriteria) criteria);
        } else if (criteria instanceof TransferCriteria) {
            logger.info("call modify(TransferCriteria)");
            modify(header, connectionId, globalReservationId, description,
                    (TransferCriteria) criteria);
        } else if (criteria != null) {
            throw ToRMS.convert(NSIExceptionUtil.makeServiceException(
                    ErrorID.UNSUPPORTED_PARAMETER, connectionId, "unsupported criteria: "
                            + criteria.getClass().getCanonicalName()));
        } else {
            throw ToRMS.convert(NSIExceptionUtil.makeServiceException(ErrorID.MISSING_PARAMETER,
                    connectionId, "criteria is null"));
        }
    }

    @Override
    public void reserve(CommonHeaderType header, String connectionId, String globalReservationId,
            String description, EthernetCriteria criteria) throws ServiceException {
        check(ether, connectionId, "EthernetResourceManager");
        ether.reserve(header, connectionId, globalReservationId, description, criteria);
    }

    @Override
    public void modify(CommonHeaderType header, String connectionId, String globalReservationId,
            String description, EthernetCriteria criteria) throws ServiceException {
        check(ether, connectionId, "EthernetResourceManager");
        ether.modify(header, connectionId, globalReservationId, description, criteria);
    }

    @Override
    public void reserve(CommonHeaderType header, String connectionId, String globalReservationId,
            String description, ODUCriteria criteria) throws ServiceException {
        check(odu, connectionId, "ODUResourceManager");
        odu.reserve(header, connectionId, globalReservationId, description, criteria);
    }

    @Override
    public void modify(CommonHeaderType header, String connectionId, String globalReservationId,
            String description, ODUCriteria criteria) throws ServiceException {
        check(odu, connectionId, "ODUResourceManager");
        odu.modify(header, connectionId, globalReservationId, description, criteria);
    }

    @Override
    public void reserve(CommonHeaderType header, String connectionId, String globalReservationId,
            String description, LambdaCriteria criteria) throws ServiceException {
        check(lambda, connectionId, "LambdaResourceManager");
        lambda.reserve(header, connectionId, globalReservationId, description, criteria);
    }

    @Override
    public void modify(CommonHeaderType header, String connectionId, String globalReservationId,
            String description, LambdaCriteria criteria) throws ServiceException {
        check(lambda, connectionId, "LambdaResourceManager");
        lambda.modify(header, connectionId, globalReservationId, description, criteria);
    }

    @Override
    public void reserve(CommonHeaderType header, String connectionId, String globalReservationId,
            String description, TransferCriteria criteria) throws ServiceException {
        check(transfer, connectionId, "TransferResourceManager");
        transfer.reserve(header, connectionId, globalReservationId, description, criteria);
    }

    @Override
    public void modify(CommonHeaderType header, String connectionId, String globalReservationId,
            String description, TransferCriteria criteria) throws ServiceException {
        check(transfer, connectionId, "TransferResourceManager");
        transfer.modify(header, connectionId, globalReservationId, description, criteria);
    }

    @Override
    public void setNotifier(Notifier notifier) {
        base.setNotifier(notifier);
    }

    @Override
    public void commit(CommonHeaderType header, String connectionId) throws ServiceException {
        base.commit(header, connectionId);
    }

    @Override
    public void abort(CommonHeaderType header, String connectionId) throws ServiceException {
        base.abort(header, connectionId);
    }

    @Override
    public void provision(CommonHeaderType header, String connectionId) throws ServiceException {
        base.provision(header, connectionId);
    }

    @Override
    public void release(CommonHeaderType header, String connectionId) throws ServiceException {
        base.release(header, connectionId);
    }

    @Override
    public void terminate(CommonHeaderType header, String connectionId) throws ServiceException {
        base.terminate(header, connectionId);
    }

}
