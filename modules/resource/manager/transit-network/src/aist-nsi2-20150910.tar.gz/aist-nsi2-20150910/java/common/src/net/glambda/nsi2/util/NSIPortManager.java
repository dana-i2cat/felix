/*
 * Copyright 2003-2013 National Institute of Advanced Industrial Science and Technology
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package net.glambda.nsi2.util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import javax.xml.namespace.QName;
import javax.xml.ws.BindingProvider;
import javax.xml.ws.WebServiceContext;
import javax.xml.ws.handler.MessageContext;

import net.glambda.nsi2.impl.ProviderPortReconnectAlways;

import org.apache.commons.logging.Log;
import org.apache.cxf.binding.soap.SoapHeader;
import org.apache.cxf.headers.Header;
import org.apache.cxf.jaxb.JAXBDataBinding;
import org.apache.cxf.message.Message;
import org.ogf.schemas.nsi._2013._12.connection._interface.ServiceException;
import org.ogf.schemas.nsi._2013._12.connection.provider.ConnectionProviderPort;
import org.ogf.schemas.nsi._2013._12.connection.requester.ConnectionRequesterPort;
import org.ogf.schemas.nsi._2013._12.framework.headers.CommonHeaderType;
import org.w3c.dom.Node;

public class NSIPortManager {

    protected static final Log logger = AbstractLog.getLog(NSIPortManager.class);

    private static final HashMap<String, ConnectionProviderPort> provPortMap =
            new LinkedHashMap<String, ConnectionProviderPort>();
    private static final HashMap<String, ConnectionRequesterPort> reqPortMap =
            new LinkedHashMap<String, ConnectionRequesterPort>();

    private static NSIPortManager INSTANCE = new NSIPortManager();

    private final Unmarshaller unmarshaller;

    private NSIPortManager() {
        Unmarshaller um;
        try {
            um =
                    JAXBContext.newInstance(CommonHeaderType.class.getPackage().getName())
                            .createUnmarshaller();
        } catch (JAXBException e) {
            um = null;
            e.printStackTrace();
            logger.fatal(e);
            System.exit(1);
        }
        unmarshaller = um;
    }

    public static NSIPortManager getInstance() {
        return INSTANCE;
    }

    public ConnectionProviderPort getProviderPort(String uri) {
        ConnectionProviderPort port;
        synchronized (provPortMap) {
            port = provPortMap.get(uri);
        }
        if (port == null) {
            port = NSIUtil.getProviderPort(uri);
            synchronized (provPortMap) {
                ConnectionProviderPort port2 = provPortMap.get(uri);
                if (port2 == null) {
                    provPortMap.put(uri, port);
                } else {
                    // dispose port
                    port = port2;
                }
            }
        }
        return port;
    }

    public ConnectionRequesterPort getRequesterPort(String uri) {
        ConnectionRequesterPort port;
        synchronized (reqPortMap) {
            port = reqPortMap.get(uri);
        }
        if (port == null) {
            port = NSIUtil.getRequesterPort(uri);
            synchronized (reqPortMap) {
                ConnectionRequesterPort port2 = reqPortMap.get(uri);
                if (port2 == null) {
                    reqPortMap.put(uri, port);
                } else {
                    // dispose port
                    port = port2;
                }
            }
        }
        return port;
    }

    private static final org.ogf.schemas.nsi._2013._12.framework.headers.ObjectFactory objFactory =
            new org.ogf.schemas.nsi._2013._12.framework.headers.ObjectFactory();

    private static final QName HEADER_QNAME = objFactory.createNsiHeader(null).getName();

    @SuppressWarnings("unchecked")
    private void setCommonHeader(Map<String, Object> map, CommonHeaderType header) {
        // see
        // http://cxf.apache.org/faq.html#FAQ-HowcanIaddsoapheaderstotherequest%2Fresponse%3F
        Header cxfHeader;
        try {
            cxfHeader =
                    new Header(HEADER_QNAME, header, new JAXBDataBinding(CommonHeaderType.class));
            List<Header> headers = new ArrayList<Header>();
            headers.add(cxfHeader);
            map.put(Header.HEADER_LIST, headers);
            //
            List<String> auth = null;
            for (Entry<String, Object> e : map.entrySet()) {
                if (e.getKey().equals(Message.PROTOCOL_HEADERS)
                        && (e.getValue() instanceof HashMap)) {
                    HashMap<String, List<String>> protHeaders =
                            (HashMap<String, List<String>>) e.getValue();
                    auth = protHeaders.get("Authorization");
                }
            }
            map.remove(Message.PROTOCOL_HEADERS);
            if (auth != null) {
                HashMap<String, List<String>> protHeaders = new HashMap<String, List<String>>();
                protHeaders.put("Authorization", auth);
                map.put(Message.PROTOCOL_HEADERS, protHeaders);
            }
        } catch (JAXBException e) {
            logger.warn("cannot set SOAP header", e);
        }
    }

    public void setCommonHeader(ConnectionProviderPort provider, CommonHeaderType header) {
        if (provider instanceof ProviderPortReconnectAlways) {
            ProviderPortReconnectAlways port = (ProviderPortReconnectAlways) provider;
            port.setCommonHeader(header);
        } else if (header != null) {
            // for client side
            setCommonHeader(((BindingProvider) provider).getRequestContext(), header);
        }
    }

    public void setCommonHeader(ConnectionRequesterPort requester, CommonHeaderType header) {
        // for client side
        setCommonHeader(((BindingProvider) requester).getRequestContext(), header);
    }

    public void setCommonHeader(WebServiceContext context, CommonHeaderType header) {
        if (context == null) {
            logger.info("WebServiceContext is null, ignore.");
            return;
        }
        // for server side
        setCommonHeader(context.getMessageContext(), header);
    }

    @SuppressWarnings("rawtypes")
    public CommonHeaderType getCommonHeader(WebServiceContext context) throws ServiceException {
        if (context == null) {
            throw NSIExceptionUtil.makeServiceException("WebServiceContext is null!");
        }
        // see
        // http://cxf.apache.org/faq.html#FAQ-HowcanIaddsoapheaderstotherequest%2Fresponse%3F
        // net.glambda.nsi2.requester.OpeBase#setCommonHeader()
        MessageContext ctx = context.getMessageContext();
        if (ctx == null) {
            throw NSIExceptionUtil.makeServiceException("missing Message Context");
        }
        Object o = ctx.get(Header.HEADER_LIST);
        if (o == null) {
            throw NSIExceptionUtil.makeServiceException("missing SOAP header list");
        } else if (!(o instanceof List)) {
            throw NSIExceptionUtil.makeServiceException("invalid SOAP header list object : "
                    + o.getClass().getName() + ", must be " + List.class.getName());
        }
        List headers = (List) o;
        if (headers.size() != 1) {
            throw NSIExceptionUtil.makeServiceException("SOAP header size is " + headers.size()
                    + ", must be 1");
        }
        o = headers.get(0);
        if (o == null) {
            throw NSIExceptionUtil.makeServiceException("SOAP header.get(0) is null");
        }
        if (!(o instanceof SoapHeader)) {
            throw NSIExceptionUtil.makeServiceException("invalid SOAP header object : "
                    + o.getClass().getName() + ", must be " + SoapHeader.class.getName());
        }
        SoapHeader cxfHeader = (SoapHeader) o;
        Object header = cxfHeader.getObject();
        if (header == null) {
            throw NSIExceptionUtil.makeServiceException("invalid SOAP header object is null");
        }
        if (header instanceof Node) {
            try {
                synchronized (unmarshaller) {
                    o = unmarshaller.unmarshal((Node) header);
                }
            } catch (JAXBException e) {
                logger.warn(e);
                throw NSIExceptionUtil.makeServiceException(e);
            }
        }
        if (o instanceof JAXBElement) {
            Object ele = ((JAXBElement) o).getValue();
            if (ele instanceof CommonHeaderType) {
                return (CommonHeaderType) ele;
            } else {
                throw NSIExceptionUtil.makeServiceException("invalid SOAP header object : "
                        + ele.getClass().getName() + ", must be "
                        + CommonHeaderType.class.getName());
            }
        } else if (o != null) {
            throw NSIExceptionUtil.makeServiceException("invalid SOAP header object : "
                    + o.getClass().getName() + ", must be " + JAXBElement.class.getName());
        } else {
            throw NSIExceptionUtil
                    .makeServiceException("invalid SOAP header object : null, must be "
                            + JAXBElement.class.getName());
        }
    }
}
