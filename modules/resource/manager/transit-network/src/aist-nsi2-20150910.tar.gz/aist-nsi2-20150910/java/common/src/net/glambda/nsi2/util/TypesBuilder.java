/*
 * Copyright 2003-2013 National Institute of Advanced Industrial Science and Technology
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package net.glambda.nsi2.util;

import java.util.Calendar;
import java.util.Collection;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.xml.bind.JAXBElement;

import net.glambda.rms.types.StpType;

import org.apache.commons.logging.Log;
import org.ogf.schemas.nsi._2013._12.connection._interface.ServiceException;
import org.ogf.schemas.nsi._2013._12.connection.types.ConnectionStatesType;
import org.ogf.schemas.nsi._2013._12.connection.types.DataPlaneStatusType;
import org.ogf.schemas.nsi._2013._12.connection.types.LifecycleStateEnumType;
import org.ogf.schemas.nsi._2013._12.connection.types.ProvisionStateEnumType;
import org.ogf.schemas.nsi._2013._12.connection.types.QuerySummaryResultCriteriaType;
import org.ogf.schemas.nsi._2013._12.connection.types.ReservationRequestCriteriaType;
import org.ogf.schemas.nsi._2013._12.connection.types.ReservationStateEnumType;
import org.ogf.schemas.nsi._2013._12.connection.types.ScheduleType;
import org.ogf.schemas.nsi._2013._12.framework.headers.CommonHeaderType;
import org.ogf.schemas.nsi._2013._12.services.point2point.P2PServiceBaseType;
import org.ogf.schemas.nsi._2013._12.services.types.DirectionalityType;
import org.ogf.schemas.nsi._2013._12.services.types.OrderedStpType;
import org.ogf.schemas.nsi._2013._12.services.types.StpListType;

public class TypesBuilder {

    protected static final Log logger = AbstractLog.getLog(TypesBuilder.class);

    public static DataPlaneStatusType makeDataPlaneStatusType(boolean bActive, Integer version,
            boolean bCons) {
        DataPlaneStatusType status = new DataPlaneStatusType();
        status.setActive(bActive);
        status.setVersion(version);
        status.setVersionConsistent(bCons);
        return status;
    }

    public static ConnectionStatesType makeConnectionStatesType(ReservationStateEnumType rsvState,
            ProvisionStateEnumType provState, LifecycleStateEnumType lifeState, boolean bActive,
            Integer version, boolean bCons) {
        ConnectionStatesType status = new ConnectionStatesType();
        status.setReservationState(rsvState);
        status.setProvisionState(provState);
        status.setLifecycleState(lifeState);
        status.setDataPlaneStatus(makeDataPlaneStatusType(bActive, version, bCons));
        return status;
    }

    // /////////////////////////////////////////////////////////////////////////

    public static CommonHeaderType makeCommonHeaderType(String reqNSA, String provNSA,
            String protVer, String replyTo) {
        CommonHeaderType nsiHeader = new CommonHeaderType();
        nsiHeader.setCorrelationId(NSIUtil.getNewCorrelationId());
        nsiHeader.setRequesterNSA(reqNSA);
        nsiHeader.setProviderNSA(provNSA);
        nsiHeader.setReplyTo(replyTo);
        nsiHeader.setProtocolVersion(protVer);
        return nsiHeader;
    }

    public static CommonHeaderType makeCommonHeaderType(String reqNSA, String provNSA,
            String replyTo) {
        return makeCommonHeaderType(reqNSA, provNSA, NSIUtil.getProviderProtocolVersion(), replyTo);
    }

    public static ScheduleType makeScheduleType(Calendar start, Calendar end) {
        ScheduleType sched = new ScheduleType();
        sched.setStartTime(start);
        sched.setEndTime(end);
        return sched;
    }

    public static OrderedStpType makeOrderedStp(String stp, int order) {
        OrderedStpType ostp = new OrderedStpType();
        ostp.setStp(stp);
        ostp.setOrder(order);
        return ostp;
    }

    private static void setP2PServiceBaseType(P2PServiceBaseType p2p, String src, String dst,
            long capacity) {
        if (capacity > 0) {
            p2p.setCapacity(capacity);
        }
        if (src != null && dst != null && capacity > 0) {
            p2p.setDirectionality(DirectionalityType.BIDIRECTIONAL);
            p2p.setSymmetricPath(true);
        }
        p2p.setSourceSTP(src);
        p2p.setDestSTP(dst);
    }

    public static P2PServiceBaseType makeP2PServiceBaseType(String src, String dst, long capacity) {
        P2PServiceBaseType p2p = new P2PServiceBaseType();
        setP2PServiceBaseType(p2p, src, dst, capacity);
        return p2p;
    }

    public static final String VLAN_MARK = "?vlan=";

    public static String makeStpWithVlan(String stp, int vlan) {
        if (vlan > 0) {
            return stp + VLAN_MARK + vlan;
        } else {
            return stp;
        }
    }

    public static int getVlan(String stp) {
        int idx = stp.indexOf(VLAN_MARK);
        if (idx > 0) {
            try {
                return Integer.parseInt(stp.substring(idx + VLAN_MARK.length()));
            } catch (NumberFormatException e) {
                logger.warn("invalid vlan: " + stp);
            }
        }
        return NSIConstants.VLANID_NOTUSE;
    }

    public static P2PServiceBaseType makeEthernetVlanType(String src, int srcvlan, String dst,
            int dstvlan, long capacity) {
        return makeP2PServiceBaseType(makeStpWithVlan(src, srcvlan), makeStpWithVlan(dst, dstvlan),
                capacity);
    }

    private static final org.ogf.schemas.nsi._2013._12.services.point2point.ObjectFactory objFactory =
            new org.ogf.schemas.nsi._2013._12.services.point2point.ObjectFactory();

    public static ReservationRequestCriteriaType makeReservationRequestCriteriaType(
            ScheduleType schedule, String src, int srcvlan, String dst, int dstvlan, long capacity) {
        ReservationRequestCriteriaType criteria = new ReservationRequestCriteriaType();
        criteria.setSchedule(schedule);
        criteria.setServiceType(NSIConstants.SERVICETYPE_ETHERNET_VLAN);
        if (src != null && dst != null && capacity > 0) {
            if (srcvlan > 0 && dstvlan > 0) {
                P2PServiceBaseType evts =
                        makeEthernetVlanType(src, srcvlan, dst, dstvlan, capacity);
                criteria.getAny().add(objFactory.createP2Ps(evts));
            } else {
                P2PServiceBaseType p2p = makeP2PServiceBaseType(src, dst, capacity);
                criteria.getAny().add(objFactory.createP2Ps(p2p));
            }
        } else if (src == null && dst == null && capacity > 0) {
            criteria.getAny().add(objFactory.createCapacity(capacity));
        }
        return criteria;
    }

    public static ReservationRequestCriteriaType makeReservationRequestCriteriaType(
            ScheduleType schedule, String src, String dst, long capacity) {
        return makeReservationRequestCriteriaType(schedule, src, 0, dst, 0, capacity);
    }

    public static ReservationRequestCriteriaType makeReservationRequestCriteriaType(
            ScheduleType schedule) {
        return makeReservationRequestCriteriaType(schedule, null, 0, null, 0, 0);
    }

    public static ReservationRequestCriteriaType makeReservationRequestCriteriaType(
            ScheduleType schedule, long bandwidth) {
        return makeReservationRequestCriteriaType(schedule, null, 0, null, 0, bandwidth);
    }

    public static Object getJAXBValue(Object o) {
        if (o == null) {
            return null;
        }
        if (o instanceof JAXBElement) {
            return ((JAXBElement<?>) o).getValue();
        } else {
            logger.warn("object is " + o.getClass().getCanonicalName() + ". must be wrapped by "
                    + JAXBElement.class.getCanonicalName());
            return null;
        }
    }

    public static Object getObject(List<Object> list) throws ServiceException {
        if (list.size() != 1) {
            throw NSIExceptionUtil.makeServiceException("criteria.any has " + list.size()
                    + " objects. must be 1");
        }
        Object o = list.get(0);
        if (!(o instanceof JAXBElement)) {
            throw NSIExceptionUtil.makeServiceException("criteria has "
                    + o.getClass().getCanonicalName() + " object. must be wrapped by "
                    + JAXBElement.class.getCanonicalName());
        }
        return ((JAXBElement<?>) o).getValue();
    }

    @SuppressWarnings("unchecked")
    public static <T> T getObject(List<Object> list, Class<T> cls) throws ServiceException {
        Object ele = getObject(list);
        if (ele == null) {
            return null;
        }
        if (!ele.getClass().equals(cls)) {
            throw NSIExceptionUtil.makeServiceException("criteria has "
                    + ele.getClass().getCanonicalName() + " object. must be "
                    + cls.getCanonicalName());
        }
        return (T) ele;
    }

    public static P2PServiceBaseType getP2PServiceBaseType(List<Object> list)
            throws ServiceException {
        Object ele = getObject(list);
        if (ele == null) {
            return null;
        }
        if (ele instanceof P2PServiceBaseType) {
            return (P2PServiceBaseType) ele;
        } else {
            throw NSIExceptionUtil.makeServiceException("unknown Data type: "
                    + ele.getClass().getCanonicalName() + ", must be "
                    + P2PServiceBaseType.class.getCanonicalName());
        }
    }

    public static P2PServiceBaseType getP2PServiceBaseType(ReservationRequestCriteriaType criteria)
            throws ServiceException {
        if (criteria == null) {
            return null;
        }
        return getP2PServiceBaseType(criteria.getAny());
    }

    public static P2PServiceBaseType getP2PServiceBaseType(QuerySummaryResultCriteriaType criteria)
            throws ServiceException {
        if (criteria == null) {
            return null;
        }
        return getP2PServiceBaseType(criteria.getAny());
    }

    public static Long getLong(List<Object> list) throws ServiceException {
        return getObject(list, Long.class);
    }

    public static final String STPID_DELIM = "@";

    public static String makeStpId(String networkId, String localId) {
        return networkId + STPID_DELIM + localId;
    }

    public static StpType makeStpType(String stpId) {
        if (stpId == null) {
            return null;
        }
        StpType result = new StpType();
        String[] v = stpId.split(STPID_DELIM);
        if (v.length == 2) {
            result.setNetworkId(v[0]);
            result.setLocalId(v[1]);
        } else {
            result.setNetworkId(localid2networkid(stpId));
            result.setLocalId(stpId);
        }
        return result;
    }

    private static final Pattern LOCALID = Pattern.compile("urn:ogf:network:([^:]+:[^:]+):.+");

    public static String localid2networkid(String localid) {
        Matcher m = LOCALID.matcher(localid);
        if (m.find()) {
            return "urn:ogf:network:" + m.group(1) + ":topology";
        } else {
            return localid;
        }
    }

    public static StpListType stps2list(String[] stps) {
        StpListType list = new StpListType();
        for (int i = 0, order = NSIConstants.INITIAL_ORDER; i < stps.length; i++, order++) {
            OrderedStpType ostp = new OrderedStpType();
            ostp.setOrder(order);
            ostp.setStp(stps[i]);
            list.getOrderedSTP().add(ostp);
        }
        return list;
    }

    public static StpListType stps2list(Collection<String> stps) {
        if (stps != null) {
            return stps2list(stps.toArray(new String[0]));
        } else {
            return null;
        }
    }

    public static StpListType reverseStpList(StpListType list) {
        if (list == null || list.getOrderedSTP().isEmpty()) {
            return list;
        }
        List<OrderedStpType> orgList = list.getOrderedSTP();
        StpListType result = new StpListType();
        List<OrderedStpType> newList = result.getOrderedSTP();
        for (int i = orgList.size() - 1, order = NSIConstants.INITIAL_ORDER; i >= 0; i--, order++) {
            OrderedStpType ostp = new OrderedStpType();
            ostp.setStp(orgList.get(i).getStp());
            ostp.setOrder(order);
            newList.add(ostp);
        }
        return result;
    }

}
