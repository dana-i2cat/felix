/*
 * Copyright 2003-2013 National Institute of Advanced Industrial Science and Technology
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package net.glambda.nsi2.requester;

import net.glambda.nsi2.impl.NSIProperties;
import net.glambda.nsi2.impl.ProviderPortWithHeader;

import org.apache.commons.cli.CommandLine;
import org.ogf.schemas.nsi._2013._12.connection._interface.Error;
import org.ogf.schemas.nsi._2013._12.connection.provider.ConnectionProviderPort;
import org.ogf.schemas.nsi._2013._12.connection.types.QuerySummaryConfirmedType;
import org.ogf.schemas.nsi._2013._12.connection.types.QuerySummaryResultType;
import org.ogf.schemas.nsi._2013._12.connection.types.QueryType;
import org.ogf.schemas.nsi._2013._12.framework.headers.CommonHeaderType;

public class TerminateAllOpe extends OpeBase {

    private static final NSIProperties nsiProp = NSIProperties.getInstance();

    protected void terminaleAll(ConnectionProviderPort provider, CommandLine cmd, String globalId)
            throws Exception {
        CommonHeaderType header = getCommonHeader();
        ProviderPortWithHeader port = new ProviderPortWithHeader(header, provider);

        // queryAll (sync)
        QueryType queryType = new QueryType();
        if (globalId != null) {
            queryType.getGlobalReservationId().add(globalId);
        }
        String myReqNSA = header.getRequesterNSA();
        header.setRequesterNSA(nsiProp.getQueryAllNSA());
        QuerySummaryConfirmedType summary;
        try {
            summary = port.querySummarySync(queryType);
        } catch (Error e) {
            throw new Exception(e.getMessage(), e);
        }

        header.setRequesterNSA(myReqNSA);
        for (QuerySummaryResultType result : summary.getReservation()) {
            System.out.println();
            String connId = result.getConnectionId();
            System.out.println("connectionID=" + connId + ", globalId="
                    + result.getGlobalReservationId() + ", LifecycleStateEnum="
                    + result.getConnectionStates().getLifecycleState());
            switch (result.getConnectionStates().getLifecycleState()) {
            case TERMINATING:
            case TERMINATED:
                continue;
            default:
                break;
            }
            System.out.println("\ttry terminate connectionId=" + connId);
            try {
                port.terminate(result.getConnectionId());
                Thread.sleep(1000);
            } catch (Exception e) {
                System.out.println("\tterminate failed for connectionId=" + connId + ", "
                        + e.getMessage());
            }
        }
    }

    @Override
    void operation(ConnectionProviderPort provider, CommandLine cmd) throws Exception {
        terminaleAll(provider, cmd, null);
    }

}
