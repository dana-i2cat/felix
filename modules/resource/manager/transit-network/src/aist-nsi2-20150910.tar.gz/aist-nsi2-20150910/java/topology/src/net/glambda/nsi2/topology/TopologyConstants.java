/*
 * Copyright 2003-2013 National Institute of Advanced Industrial Science and Technology
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package net.glambda.nsi2.topology;

public interface TopologyConstants {

    String TYPE_DDS_NSA = "vnd.ogf.nsi.nsa.v1+xml";
    String TYPE_DDS_TOPOLOGY = "vnd.ogf.nsi.topology.v2+xml";
    String TYPE_DDS_uPA = "vnd.ogf.nsi.cs.v2.role.uPA";
    String TYPE_DDS_AGGREGATOR = "vnd.ogf.nsi.cs.v2.role.aggregator";

    String TYPE_SERVICE = "application/vnd.org.ogf.nsi.cs.v2+soap";
    String TYPE_TOPOLOGY = "application/vnd.ogf.nsi.topology.v2+xml";
    String TYPE_REQUESTER = "application/vnd.ogf.nsi.cs.v2.requester+soap";
    String TYPE_PROVIDER = "application/vnd.ogf.nsi.cs.v2.provider+soap";
    String TYPE_PROVIDED_BY = "http://schemas.ogf.org/nsi/2013/09/topology#providedBy";

    String TYPE_IN_BOUND_PORT = "http://schemas.ogf.org/nml/2013/05/base#hasInboundPort";
    String TYPE_OUT_BOUND_PORT = "http://schemas.ogf.org/nml/2013/05/base#hasOutboundPort";

    String TYPE_VLAN = "http://schemas.ogf.org/nml/2012/10/ethernet#vlan";
    String DEFAULT_VLAN = "1780-1783";

    String TYPE_IS_ALIAS = "http://schemas.ogf.org/nml/2013/05/base#isAlias";

    String TYPE_PEER_WITH = "http://schemas.ogf.org/nsi/2013/09/topology#peersWith";
    String TYPE_ADMIN_CONTACT = "http://schemas.ogf.org/nsi/2013/09/topology#adminContact";

}
