/*
 * Copyright 2003-2013 National Institute of Advanced Industrial Science and Technology
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package net.glambda.nsi2.impl;

import java.util.Calendar;
import java.util.List;

import javax.annotation.Resource;
import javax.xml.ws.WebServiceContext;

import net.glambda.nsi2.util.NSITextDump;
import net.glambda.nsi2.util.AbstractLog;
import net.glambda.nsi2.util.NSIPortManager;

import org.apache.commons.logging.Log;
import org.ogf.schemas.nsi._2013._12.connection.types.ReserveConfirmedType;
import org.ogf.schemas.nsi._2013._12.framework.headers.CommonHeaderType;
import org.ogf.schemas.nsi._2013._12.connection._interface.ServiceException;
import org.ogf.schemas.nsi._2013._12.connection.requester.ConnectionRequesterPort;
import org.ogf.schemas.nsi._2013._12.connection.types.ConnectionStatesType;
import org.ogf.schemas.nsi._2013._12.connection.types.DataPlaneStatusType;
import org.ogf.schemas.nsi._2013._12.connection.types.EventEnumType;
import org.ogf.schemas.nsi._2013._12.connection.types.GenericAcknowledgmentType;
import org.ogf.schemas.nsi._2013._12.connection.types.QueryNotificationConfirmedType;
import org.ogf.schemas.nsi._2013._12.connection.types.QueryRecursiveResultType;
import org.ogf.schemas.nsi._2013._12.connection.types.QueryResultResponseType;
import org.ogf.schemas.nsi._2013._12.connection.types.QuerySummaryResultType;
import org.ogf.schemas.nsi._2013._12.connection.types.ReservationConfirmCriteriaType;
import org.ogf.schemas.nsi._2013._12.framework.types.ServiceExceptionType;
import org.ogf.schemas.nsi._2013._12.framework.types.TypeValuePairListType;

@javax.jws.WebService(portName = "ConnectionServiceRequesterPort", serviceName = "ConnectionServiceRequester", targetNamespace = "http://schemas.ogf.org/nsi/2013/12/connection/requester", endpointInterface = "org.ogf.schemas.nsi._2013._12.connection.requester.ConnectionRequesterPort")
public class SampleRequester implements ConnectionRequesterPort {

    protected static final Log logger = AbstractLog.getLog(SampleRequester.class);
    private static final NSIPortManager portMgr = NSIPortManager.getInstance();

    // NOTE: see the bottom of http://cxf.apache.org/docs/servlet-transport.html
    @Resource
    private WebServiceContext context;

    private final boolean bSysOutLog;
    private boolean silentLog = false;

    public SampleRequester(boolean bSysOutLog) {
        this.bSysOutLog = bSysOutLog;
    }

    public SampleRequester() {
        this(true);
    }

    public boolean isSilentLog() {
        return silentLog;
    }

    public void setSilentLog(boolean silentLog) {
        this.silentLog = silentLog;
    }

    protected void log(String msg) {
        if (bSysOutLog) {
            System.out.println(msg.replace("\t", ""));
        } else {
            logger.info(msg);
        }
    }

    private void log(String text, String o, boolean bRecv) {
        if (silentLog) {
            log(o);
        } else {
            log(NSITextDump.addTab(text, o, bRecv));
        }
    }

    private CommonHeaderType lastHeader = null;

    public CommonHeaderType getLastHeader() {
        return lastHeader;
    }

    private synchronized CommonHeaderType getHeader() throws ServiceException {
        lastHeader = portMgr.getCommonHeader(context);
        return lastHeader;
    }

    protected CommonHeaderType reserveConfirmedHeader(String connectionId,
            String globalReservationId, String description, ReservationConfirmCriteriaType criteria)
            throws ServiceException {
        final CommonHeaderType header = getHeader();
        ReserveConfirmedType rsvConf = new ReserveConfirmedType();
        rsvConf.setGlobalReservationId(globalReservationId);
        rsvConf.setDescription(description);
        rsvConf.setConnectionId(connectionId);
        rsvConf.setCriteria(criteria);
        log(NSITextDump.toString(header, rsvConf), "ReserveConfirmed", true);
        portMgr.setCommonHeader(context, header);
        return header;
    }

    @Override
    public void reserveConfirmed(String connectionId, String globalReservationId,
            String description, ReservationConfirmCriteriaType criteria) throws ServiceException {
        reserveConfirmedHeader(connectionId, globalReservationId, description, criteria);
    }

    protected CommonHeaderType genericFailedHeader(String ope, String connectionId,
            ConnectionStatesType connectionStates, ServiceExceptionType serviceException)
            throws ServiceException {
        final CommonHeaderType header = getHeader();
        log(NSITextDump.toString(header, connectionId, connectionStates, serviceException), ope,
                true);
        portMgr.setCommonHeader(context, header);
        return header;
    }

    @Override
    public void reserveFailed(String connectionId, ConnectionStatesType connectionStates,
            ServiceExceptionType serviceException) throws ServiceException {
        genericFailedHeader("ReserveFailed", connectionId, connectionStates, serviceException);
    }

    protected CommonHeaderType genericConfirmedHeader(String ope, String connectionId)
            throws ServiceException {
        final CommonHeaderType header = getHeader();
        log(NSITextDump.toString(header, connectionId), ope, true);
        portMgr.setCommonHeader(context, header);
        return header;
    }

    @Override
    public void reserveCommitConfirmed(String connectionId) throws ServiceException {
        genericConfirmedHeader("reserveCommitConfirmed", connectionId);
    }

    @Override
    public void reserveCommitFailed(String connectionId, ConnectionStatesType connectionStates,
            ServiceExceptionType serviceException) throws ServiceException {
        genericFailedHeader("reserveCommitFailed", connectionId, connectionStates, serviceException);
    }

    @Override
    public void reserveAbortConfirmed(String connectionId) throws ServiceException {
        genericConfirmedHeader("reserveAbortConfirmed", connectionId);
    }

    protected CommonHeaderType reserveTimeoutHeader(String connectionId, long notificationId,
            Calendar timeStamp, int timeoutValue, String originatingConnectionId,
            String originatingNSA) throws ServiceException {
        final CommonHeaderType header = getHeader();
        log(NSITextDump.toString(header, connectionId, notificationId, timeStamp, timeoutValue,
                originatingConnectionId, originatingNSA), "reserveTimeout", true);
        portMgr.setCommonHeader(context, header);
        return header;
    }

    @Override
    public void reserveTimeout(String connectionId, long notificationId, Calendar timeStamp,
            int timeoutValue, String originatingConnectionId, String originatingNSA)
            throws ServiceException {
        reserveTimeoutHeader(connectionId, notificationId, timeStamp, timeoutValue,
                originatingConnectionId, originatingNSA);
    }

    @Override
    public void provisionConfirmed(String connectionId) throws ServiceException {
        genericConfirmedHeader("provisionConfirmed", connectionId);
    }

    @Override
    public void releaseConfirmed(String connectionId) throws ServiceException {
        genericConfirmedHeader("releaseConfirmed", connectionId);
    }

    @Override
    public void terminateConfirmed(String connectionId) throws ServiceException {
        genericConfirmedHeader("terminateConfirmed", connectionId);
    }

    protected CommonHeaderType querySummaryConfirmedHeader(List<QuerySummaryResultType> reservation)
            throws ServiceException {
        final CommonHeaderType header = getHeader();
        log(NSITextDump.toStringQuerySummayList(header, reservation), "querySummaryConfirmed", true);
        portMgr.setCommonHeader(context, header);
        return header;
    }

    @Override
    public void querySummaryConfirmed(List<QuerySummaryResultType> reservation)
            throws ServiceException {
        querySummaryConfirmedHeader(reservation);
    }

    protected CommonHeaderType genericFailedHeader(String ope, ServiceExceptionType serviceException)
            throws ServiceException {
        final CommonHeaderType header = getHeader();
        log(NSITextDump.toString(header, serviceException), ope, true);
        portMgr.setCommonHeader(context, header);
        return header;
    }

    protected CommonHeaderType queryRecursiveConfirmedHeader(
            List<QueryRecursiveResultType> reservation) throws ServiceException {
        final CommonHeaderType header = getHeader();
        log(NSITextDump.toStringQueryRecursiveList(header, reservation), "QueryRecursiveConfirmed",
                false);
        portMgr.setCommonHeader(context, header);
        return header;
    }

    @Override
    public void queryRecursiveConfirmed(List<QueryRecursiveResultType> reservation)
            throws ServiceException {
        queryRecursiveConfirmedHeader(reservation);
    }

    protected CommonHeaderType queryNotificationConfirmedHeader(
            QueryNotificationConfirmedType queryNotificationConfirmed) throws ServiceException {
        final CommonHeaderType header = getHeader();
        log(NSITextDump.toString(header, queryNotificationConfirmed), "QueryNotificationConfirmed",
                true);
        portMgr.setCommonHeader(context, header);
        return header;
    }

    @Override
    public GenericAcknowledgmentType queryNotificationConfirmed(
            QueryNotificationConfirmedType queryNotificationConfirmed) throws ServiceException {
        queryNotificationConfirmedHeader(queryNotificationConfirmed);
        return new GenericAcknowledgmentType();
    }

    protected CommonHeaderType messageDeliveryTimeoutHeader(String connectionId,
            long notificationId, Calendar timeStamp, String correlationId) throws ServiceException {
        final CommonHeaderType header = getHeader();
        log(NSITextDump.toString(header, connectionId, notificationId, timeStamp, correlationId),
                "MessageDeliveryTimeout", true);
        portMgr.setCommonHeader(context, header);
        return header;
    }

    @Override
    public void messageDeliveryTimeout(String connectionId, long notificationId,
            Calendar timeStamp, String correlationId) throws ServiceException {
        messageDeliveryTimeoutHeader(connectionId, notificationId, timeStamp, correlationId);
    }

    protected CommonHeaderType dataPlaneStateChangeHeader(String connectionId, long notificationId,
            Calendar timeStamp, DataPlaneStatusType dataPlaneStatus) throws ServiceException {
        final CommonHeaderType header = getHeader();
        log(NSITextDump.toString(header, connectionId, notificationId, timeStamp, dataPlaneStatus),
                "DataPlaneStateChange", true);
        portMgr.setCommonHeader(context, header);
        return header;
    }

    @Override
    public void dataPlaneStateChange(String connectionId, long notificationId, Calendar timeStamp,
            DataPlaneStatusType dataPlaneStatus) throws ServiceException {
        dataPlaneStateChangeHeader(connectionId, notificationId, timeStamp, dataPlaneStatus);
    }

    protected CommonHeaderType errorEventHeader(String connectionId, long notificationId,
            Calendar timeStamp, EventEnumType event, TypeValuePairListType additionalInfo,
            ServiceExceptionType serviceException) throws ServiceException {
        final CommonHeaderType header = getHeader();
        log(NSITextDump.toString(header, connectionId, notificationId, timeStamp, event,
                additionalInfo, serviceException), "ErrorEvent", true);
        portMgr.setCommonHeader(context, header);
        return header;
    }

    @Override
    public void errorEvent(String connectionId, long notificationId, Calendar timeStamp,
            EventEnumType event, String originatingConnectionId, String originatingNSA,
            TypeValuePairListType additionalInfo, ServiceExceptionType serviceException)
            throws ServiceException {
        errorEventHeader(connectionId, notificationId, timeStamp, event, additionalInfo,
                serviceException);
    }

    protected CommonHeaderType errorHeader(ServiceExceptionType serviceException)
            throws ServiceException {
        final CommonHeaderType header = getHeader();
        log(NSITextDump.toString(header, serviceException), "Error", true);
        portMgr.setCommonHeader(context, header);
        return header;
    }

    @Override
    public void error(ServiceExceptionType serviceException) throws ServiceException {
        errorHeader(serviceException);
    }

    @Override
    public void queryResultConfirmed(List<QueryResultResponseType> result) throws ServiceException {
        // TODO Auto-generated method stub

    }

}
