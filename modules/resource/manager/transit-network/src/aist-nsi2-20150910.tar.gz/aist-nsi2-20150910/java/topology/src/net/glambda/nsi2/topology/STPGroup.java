/*
 * Copyright 2003-2013 National Institute of Advanced Industrial Science and Technology
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package net.glambda.nsi2.topology;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;

public class STPGroup extends STP {

    private static final HashMap<String, STPGroup> port2biMap = new HashMap<String, STPGroup>();

    private final LinkedList<STP> ports = new LinkedList<STP>();
    private final STP in, out;

    public STPGroup(String name, STPType type, List<String> portNames) {
        super(name, null, null, type);
        port2biMap.put(name, this);
        STP i = null, o = null;
        for (String portName : portNames) {
            STP stp = STP.findSTP(portName);
            if (stp != null) {
                this.ports.add(stp);
                port2biMap.put(portName, this);
                if (stp.type() == STPType.IN) {
                    i = stp;
                } else if (stp.type() == STPType.OUT) {
                    o = stp;
                }
            } else {
                logger.error("unknown STP: PortGroup id=\"" + portName
                        + "\" in BidirectionalPort id=\"" + name + "\"");
            }
        }
        this.in = i;
        this.out = o;
    }

    public LinkedList<STP> ports() {
        return ports;
    }

    public STP inPort() {
        return in;
    }

    public STP outPort() {
        return out;
    }

    public boolean isConnectedTo(STPGroup other) {
        if (other == null || this.out == null || other.in == null) {
            return false;
        }
        // only check one direction
        return (this.out.connectedTo() == other.in);
    }

    public static STPGroup findSTPGroup(String portName) {
        // find by STPGroup name and STP name which related to the STPGroup
        STPGroup group = port2biMap.get(portName);
        if (group != null) {
            return group;
        } else {
            logger.warn("cannot find STPGroup for STP: " + portName);
            return null;
        }
    }

    public VLanRange vlans() {
        if (ports.isEmpty()) {
            return VLanRange.getDefaultRange();
        } else {
            return ports.get(0).vlans();
        }
    }

}
