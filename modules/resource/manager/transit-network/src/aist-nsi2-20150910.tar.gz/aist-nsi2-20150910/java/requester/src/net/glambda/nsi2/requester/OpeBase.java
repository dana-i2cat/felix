/*
 * Copyright 2003-2013 National Institute of Advanced Industrial Science and Technology
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package net.glambda.nsi2.requester;

import java.util.ArrayList;
import java.util.Calendar;

import net.glambda.nsi2.util.AbstractLog;
import net.glambda.nsi2.util.NSIConstants;
import net.glambda.nsi2.util.StpidVlan;
import net.glambda.nsi2.util.TypesBuilder;

import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.Option;
import org.apache.commons.cli.OptionBuilder;
import org.apache.commons.cli.Options;
import org.apache.commons.logging.Log;
import org.ogf.schemas.nsi._2013._12.connection.provider.ConnectionProviderPort;
import org.ogf.schemas.nsi._2013._12.connection.types.ReservationRequestCriteriaType;
import org.ogf.schemas.nsi._2013._12.connection.types.ScheduleType;
import org.ogf.schemas.nsi._2013._12.framework.headers.CommonHeaderType;

public abstract class OpeBase {

    protected static final Log logger = AbstractLog.getLog(OpeBase.class);

    public final static String OPT_CONNID = "c";
    public final static String OPT_SRCSTP = "s";
    public final static String OPT_DSTSTP = "d";
    public final static String OPT_DESCRIPTION = "D";
    public final static String OPT_GLOBALID = "g";
    public final static String OPT_BANDWIDTH = "b";
    public final static String OPT_DURATION = "m";
    public final static String OPT_OFFSET = "o";
    public final static String OPT_STARTTIME = "start";
    public final static String OPT_ENDTIME = "end";
    public final static String OPT_SERVICETYPE = "t";
    public final static String OPT_VERSION = "v";

    public final static String OPT_SILENT = "silent";

    private Options makeOptions() {
        Options options = new Options();
        addOptions(options);
        OptionBuilder.withDescription("silent mode");
        options.addOption(OptionBuilder.create(OPT_SILENT));
        return options;
    }

    protected void addOptions(Options options) {
        // override if you want
    }

    protected void addConnIDOption(Options options) {
        OptionBuilder.hasArgs(1);
        OptionBuilder.withArgName("ConnectionID");
        OptionBuilder.isRequired(true);
        OptionBuilder.withDescription("Index of ConnectionID, or UUID");
        Option cidOption = OptionBuilder.create(OPT_CONNID);
        options.addOption(cidOption);
    }

    protected void addScheduleOption(Options options) {
        // NOTE: starTime == null, endTime == null are allowed in NSI2
        OptionBuilder.hasArgs(1);
        OptionBuilder.withArgName("startTime");
        OptionBuilder.withDescription("reservation startTime: " + TimeParser.supportedFormat());
        options.addOption(OptionBuilder.create(OPT_STARTTIME));

        OptionBuilder.hasArgs(1);
        OptionBuilder.withArgName("endTime");
        OptionBuilder.withDescription("reservation endTime: " + TimeParser.supportedFormat());
        options.addOption(OptionBuilder.create(OPT_ENDTIME));

        OptionBuilder.hasArgs(1);
        OptionBuilder.withArgName("duration");
        OptionBuilder.withDescription("reservation duration in minutes");
        options.addOption(OptionBuilder.create(OPT_DURATION));

        OptionBuilder.hasArgs(1);
        OptionBuilder.withArgName("offset");
        OptionBuilder.withDescription("reservation start time offset in minutes");
        options.addOption(OptionBuilder.create(OPT_OFFSET));
    }

    protected void addBandwidthOption(Options options, boolean isRequired) {
        OptionBuilder.hasArgs(1);
        OptionBuilder.isRequired(isRequired);
        OptionBuilder.withArgName("bandwidth");
        OptionBuilder.withDescription("reservation bandwidth [Mbps]");
        options.addOption(OptionBuilder.create(OPT_BANDWIDTH));
    }

    protected void addSrcDestOption(Options options) {
        OptionBuilder.hasArgs(1);
        OptionBuilder.isRequired(true);
        OptionBuilder.withArgName("stpid");
        OptionBuilder.withDescription("sourceSTP");
        options.addOption(OptionBuilder.create(OPT_SRCSTP));

        OptionBuilder.hasArgs(1);
        OptionBuilder.isRequired(true);
        OptionBuilder.withArgName("stpid");
        OptionBuilder.withDescription("destinationSTP");
        options.addOption(OptionBuilder.create(OPT_DSTSTP));
    }

    protected void addSrcDestOptionWithoutVlan(Options options) {
        OptionBuilder.hasArgs(1);
        OptionBuilder.isRequired(true);
        OptionBuilder.withArgName("stpid");
        OptionBuilder.withDescription("sourceSTP");
        options.addOption(OptionBuilder.create(OPT_SRCSTP));

        OptionBuilder.hasArgs(1);
        OptionBuilder.isRequired(true);
        OptionBuilder.withArgName("stpid");
        OptionBuilder.withDescription("destinationSTP");
        options.addOption(OptionBuilder.create(OPT_DSTSTP));
    }

    protected static final char STPLIST_DELIM = ' ';

    protected void addSTPListOption(Options options, boolean bRequired, String key, String desc) {
        OptionBuilder.hasArgs(1);
        OptionBuilder.hasOptionalArgs();
        OptionBuilder.withValueSeparator(STPLIST_DELIM);
        OptionBuilder.isRequired(bRequired);
        OptionBuilder.withArgName("stpid[" + STPLIST_DELIM + "stpid2" + STPLIST_DELIM + "stpid3"
                + STPLIST_DELIM + "...]");
        OptionBuilder.withDescription(desc);
        options.addOption(OptionBuilder.create(key));
    }

    protected void addCriteriaOption(Options options, boolean isRequired) {
        addSrcDestOption(options);
        addScheduleOption(options);
        addBandwidthOption(options, isRequired);
    }

    protected void addGlobalOptions(Options options, boolean bRequired) {
        OptionBuilder.hasArgs(1);
        OptionBuilder.isRequired(bRequired);
        OptionBuilder.withArgName("globalId");
        OptionBuilder.withDescription("GlobalReservationID");
        options.addOption(OptionBuilder.create(OPT_GLOBALID));
    }

    protected void addGlobalDescVerOptions(Options options) {
        OptionBuilder.hasArgs(1);
        OptionBuilder.withArgName("description");
        OptionBuilder.withDescription("Description of request");
        options.addOption(OptionBuilder.create(OPT_DESCRIPTION));

        addGlobalOptions(options, false);

        OptionBuilder.hasArgs(1);
        OptionBuilder.withArgName("version");
        OptionBuilder.withDescription("new version of the reservation (default: "
                + NSIConstants.INITIAL_VERSION + ", \"null\" to set null");
        options.addOption(OptionBuilder.create(OPT_VERSION));
    }

    protected void addServiceTypeOption(Options options) {
        OptionBuilder.hasArgs(1);
        OptionBuilder.withArgName("servicetype");
        OptionBuilder.withDescription("ServiceType of ReservationCriteria (default: "
                + NSIConstants.SERVICETYPE_ETHERNET_VLAN + ")");
        options.addOption(OptionBuilder.create(OPT_SERVICETYPE));
    }

    private ScheduleType makeSchedByOffsetDuration(CommandLine cmd) {
        Calendar start = null, end = null;
        if (cmd.hasOption(OPT_OFFSET)) {
            start = Calendar.getInstance();
            start.add(Calendar.MINUTE, Integer.parseInt(cmd.getOptionValue(OPT_OFFSET, "1")));
            start.set(Calendar.MILLISECOND, 0);
            if (cmd.hasOption(OPT_DURATION)) {
                end = (Calendar) start.clone();
                String v = cmd.getOptionValue(OPT_DURATION, "1");
                end.add(Calendar.MINUTE, Integer.parseInt(v));
            }
        }
        return TypesBuilder.makeScheduleType(start, end);
    }

    private ScheduleType makeSchedByAbsTime(CommandLine cmd) {
        Calendar start = TimeParser.parse(cmd.getOptionValue(OPT_STARTTIME));
        Calendar end = TimeParser.parse(cmd.getOptionValue(OPT_ENDTIME));
        return TypesBuilder.makeScheduleType(start, end);
    }

    protected ScheduleType makeSched(CommandLine cmd) throws Exception {
        if (cmd.hasOption(OPT_STARTTIME) || cmd.hasOption(OPT_ENDTIME)) {
            if (cmd.hasOption(OPT_OFFSET) || cmd.hasOption(OPT_DURATION)) {
                throw new Exception("invalid schedule options: cannot use " + OPT_STARTTIME + "&"
                        + OPT_ENDTIME + " and " + OPT_OFFSET + "&" + OPT_DURATION + " at once");
            }
            return makeSchedByAbsTime(cmd);
        }
        if (cmd.hasOption(OPT_OFFSET) && cmd.hasOption(OPT_DURATION)) {
            if (cmd.hasOption(OPT_STARTTIME) || cmd.hasOption(OPT_ENDTIME)) {
                throw new Exception("invalid schedule options: cannot use " + OPT_STARTTIME + "&"
                        + OPT_ENDTIME + " and " + OPT_OFFSET + "&" + OPT_DURATION + " at once");
            }
            return makeSchedByOffsetDuration(cmd);
        }
        // NOTE: no schedule option at modification
        return null;
    }

    protected StpidVlan makeSTP(CommandLine cmd, String opt) {
        if (!cmd.hasOption(opt)) {
            return null;
        }
        return new StpidVlan(cmd.getOptionValue(opt));
    }

    protected ReservationRequestCriteriaType makeBasicCriteria(CommandLine cmd) throws Exception {
        ReservationRequestCriteriaType crit;
        ScheduleType schedule = makeSched(cmd);
        if (cmd.hasOption(OPT_BANDWIDTH)) {
            String src = cmd.getOptionValue(OPT_SRCSTP);
            String dst = cmd.getOptionValue(OPT_DSTSTP);
            try {
                int bandwidth = Integer.parseInt(cmd.getOptionValue(OPT_BANDWIDTH));
                crit =
                        TypesBuilder.makeReservationRequestCriteriaType(schedule, src, dst,
                                bandwidth);
            } catch (NumberFormatException e) {
                throw new Exception("invalid bandwidth: " + cmd.getOptionValue(OPT_BANDWIDTH));
            }
        } else {
            crit = TypesBuilder.makeReservationRequestCriteriaType(schedule);
        }
        if (cmd.hasOption(OPT_SERVICETYPE)) {
            crit.setServiceType(cmd.getOptionValue(OPT_SERVICETYPE));
        }
        return crit;
    }

    protected ReservationRequestCriteriaType setVersion(CommandLine cmd,
            ReservationRequestCriteriaType criteria) {
        if (cmd.hasOption(OPT_VERSION)) {
            String v = cmd.getOptionValue(OPT_VERSION);
            if (v.equals("null")) {
                criteria.setVersion(null);
            } else {
                criteria.setVersion(Integer.parseInt(v));
            }
        } else {
            criteria.setVersion(NSIConstants.INITIAL_VERSION);
        }
        return criteria;
    }

    protected static final ArrayList<String> connIdList = new ArrayList<String>();

    protected synchronized static int putConnectionID(String connId) {
        connIdList.add(connId);
        int idx = connIdList.size() - 1;
        System.out.println("*** ConnectionID[" + idx + "] = " + connId);
        return idx;
    }

    protected synchronized static String getConnectionID(String id) throws Exception {
        if (id == null || id.isEmpty()) {
            throw new Exception("ID is empty/invalid");
        }

        try {
            int n = Integer.parseInt(id);
            if ((0 <= n) && (n < connIdList.size())) {
                String connId = connIdList.get(n);
                System.out.println("*** ConnectionID[" + n + "] = " + connId);
                return connId;
            } else {
                throw new Exception("Invalid ConnectionID index: " + n);
            }
        } catch (NumberFormatException e) {
            return id;
        }
    }

    protected synchronized static String getConnectionID(CommandLine cmd) throws Exception {
        return getConnectionID(cmd.getOptionValue(OPT_CONNID, ""));
    }

    private final Options cmdOptions = makeOptions();

    public Options getOptions() {
        return cmdOptions;
    }

    abstract void operation(ConnectionProviderPort provider, CommandLine cmd) throws Exception;

    protected CommonHeaderType getCommonHeader(String replyTo) {
        String reqNSA = mainCmd.getOptionValue(SimpleNSIRequester.OPT_REQ_NAME);
        String provNSA = mainCmd.getOptionValue(SimpleNSIRequester.OPT_PROV_NAME);
        if (replyTo != null) {
            return TypesBuilder.makeCommonHeaderType(reqNSA, provNSA, replyTo);
        } else {
            return TypesBuilder.makeCommonHeaderType(reqNSA, provNSA, null);
        }
    }

    protected CommonHeaderType getCommonHeader() {
        String replyTo = mainCmd.getOptionValue(SimpleNSIRequester.OPT_REQ_URI);
        return getCommonHeader(replyTo);
    }

    private static CommandLine mainCmd = null;

    public static void setParams(CommandLine mainCmd) {
        OpeBase.mainCmd = mainCmd;
    }

    protected void log(CommandLine cmd, String txt) {
        if (cmd.hasOption(OPT_SILENT)) {
            return;
        }
        System.out.println(txt);
    }
}
